# Download link of bag files

- [TB3_WAFFLE_SLAM.bag](https://github.com/ROBOTIS-GIT/bags) 
- Commands for download:
```bash
roscd turtlebot3_slam/bag
wget https://github.com/ROBOTIS-GIT/bags/raw/master/TB3_WAFFLE_SLAM.bag
```
